使用指南

1，安装 requests 库 
    pip install requests
2， 下载python send_verification_code.py。
  
3，在cmd命令行里运行
   cd python send_verification_code.py所在的文件。
         记得把手机账号改成你自己的）
   输入  python send_verification_code.py
   回车
   显示  服务器响应: jsonpReturn({"result":1,"msg":"验证码正下发，请注意查收！"});
   成功
4，手机接收信息 登录 NJUPT。 账号为输入的号， 密码看手机接收到的信息。
   
